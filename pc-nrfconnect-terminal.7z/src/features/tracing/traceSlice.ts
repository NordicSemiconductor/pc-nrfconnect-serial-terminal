/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-4-Clause
 */

import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import type { RootState } from '../../appReducer';

interface TraceState {
    serialPort: string | null;
    availableSerialPorts: string[];
}

const initialState = (): TraceState => ({
    serialPort: null,
    availableSerialPorts: [],
});

const traceSlice = createSlice({
    name: 'trace',
    initialState: initialState(),
    reducers: {
        setAvailableSerialPorts: (state, action: PayloadAction<string[]>) => {
            state.availableSerialPorts = action.payload;
        },
        setSerialPort: (state, action: PayloadAction<string | null>) => {
            state.serialPort = action.payload;
        },
    },
});

export const getSerialPort = (state: RootState) => state.app.trace.serialPort;
export const getIsDeviceSelected = (state: RootState) =>
    state.app.trace.serialPort != null;

export const getAvailableSerialPorts = (state: RootState) =>
    state.app.trace.availableSerialPorts;

export const { setSerialPort, setAvailableSerialPorts } = traceSlice.actions;

export default traceSlice.reducer;
