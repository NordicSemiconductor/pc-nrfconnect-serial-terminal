/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-4-Clause
 */

import { NrfConnectState } from 'pc-nrfconnect-shared';
import { AnyAction } from 'redux';
import { ThunkDispatch } from 'redux-thunk';

interface SerialState {
    serialPort: string | null;
    availableSerialPorts: string[];
}

const initialState = (): SerialState => ({
    serialPort: null,
    availableSerialPorts: [],
});

const traceSlice = createSlice({
    name: 'serial',
    initialState: initialState(),
    reducers: {
        setAvailableSerialPorts: (state, action: PayloadAction<string[]>) => {
            state.availableSerialPorts = action.payload;
        },
        setSerialPort: (state, action: PayloadAction<string | null>) => {
            state.serialPort = action.payload;
        },
    },
});

interface AppState {
    terminalStates: TerminalStates;
}

export type RootState = NrfConnectState<AppState>;
export type TDispatch = ThunkDispatch<RootState, null, AnyAction>;
