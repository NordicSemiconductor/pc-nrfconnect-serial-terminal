/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-4-Clause
 */

import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import type { RootState } from './types';

interface SerialState {
    serialPort: string | null;
    availableSerialPorts: string[];
}

const initialState = (): SerialState => ({
    serialPort: null,
    availableSerialPorts: [],
});

const serialSlice = createSlice({
    name: 'trace',
    initialState: initialState(),
    reducers: {
        setAvailableSerialPorts: (state, action: PayloadAction<string[]>) => {
            state.availableSerialPorts = action.payload;
        },
        setSerialPort: (state, action: PayloadAction<string | null>) => {
            state.serialPort = action.payload;
        },
    },
});

export default serialSlice.reducer;

export const { setSerialPort, setAvailableSerialPorts } = serialSlice.actions;

export const getSerialPort = (state: RootState) => state.app.trace.serialPort;
export const getIsDeviceSelected = (state: RootState) =>
    state.app.trace.serialPort != null;

export const getAvailableSerialPorts = (state: RootState) =>
    state.app.trace.availableSerialPorts;
