/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-4-Clause
 */

declare module '@nordicsemiconductor/nrf-monitor-lib-js/package.json' {
    export const name: string;
    export const version: string;
}
