/*
 * Copyright (c) 2015 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-4-Clause
 */

import { getPersistentStore as store } from 'pc-nrfconnect-shared';

interface DevicePort {
    [serialNumber: string]: string;
}

const SERIALPORTS = 'serialPorts';
const POPOUT_TERMINAL = 'popoutTerminal';

interface StoreSchema {
    [SERIALPORTS]: DevicePort;
    [POPOUT_TERMINAL]: boolean;
}

const serialPorts = () => store<StoreSchema>().get(SERIALPORTS, {});
export const getSerialPort = (serialNumber: string) =>
    serialPorts()[serialNumber];

export const setSerialPort = (serialNumber: string, port: string) =>
    store<StoreSchema>().set(SERIALPORTS, {
        ...serialPorts(),
        [serialNumber]: port,
    });

export const getPopoutTerminal = () =>
    store<StoreSchema>().get(POPOUT_TERMINAL, false);
export const setPopoutTerminal = (popoutTerminal: boolean) =>
    store<StoreSchema>().set(POPOUT_TERMINAL, popoutTerminal);
